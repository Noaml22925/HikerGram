package com.example.hikergram;

import java.util.ArrayList;
import java.util.List;

public class Post {
    // Fields
    private User user;
    private String nameOfTheHike;
    private String description;
    private String imageUrl;
    private int difficulty;
    private int likes;
    private ArrayList<Comment> comments;

    // Constructor
    public Post(){}

    public Post(User user, String nameOfTheHike, String description, String imageUrl, int difficulty) {
        this.user = user;
        this.nameOfTheHike = nameOfTheHike;
        this.description = description;
        this.imageUrl = imageUrl;
        this.difficulty = difficulty;
        this.likes = 0;
        this.comments = new ArrayList<Comment>();
    }


    // Getters and setters


    public User getUser() {
        return user;
    }

    public String getNameOfTheHike() {
        return nameOfTheHike;
    }

    public String getDescription() {
        return description;
    }

    public String getImageUrl() {
        return this.imageUrl;
    }

    public int getDifficulty() {
        return difficulty;
    }

    public int getLikes() {
        return this.likes;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public void setNameOfTheHike(String nameOfTheHike) {
        this.nameOfTheHike = nameOfTheHike;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public void setDifficulty(int difficulty) {
        this.difficulty = difficulty;
    }

    // Other methods
    public void like() {
        this.likes++;
    }

    public void addComment(Comment comment) {
        this.comments.add(comment);
    }
}